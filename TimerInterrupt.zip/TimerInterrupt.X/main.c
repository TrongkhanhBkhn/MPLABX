#include <xc.h>


//set the configuration bits: internal OSC, everything off except MCLR
#pragma config FOSC =INTRC_CLKOUT
#pragma config WDTE=OFF
#pragma config PWRTE=OFF
#pragma config MCLRE=ON
 #pragma config CP=OFF

#pragma config CPD=OFF
#pragma config BOREN=OFF
#pragma config IESO=OFF
#pragma config FCMEN=OFF

#define _XTAL_FREQ 4000000
int count=0;
void interrupt isr()
{
    INTCONbits.T0IF = 0;        
    TMR0 = 0;                  
                               
    count++;
    if(count ==10){
    PORTBbits.RB7 = ~PORTBbits.RB7; 
    count  = 0;
    }
}

int main()
{
    TRISA = 0xFF;   //set all digital I/O to inputs
    TRISB = 0xFF;
    TRISC = 0xFF;

    ANSEL = 0x00;   //disable all analog ports
    ANSELH = 0x00;

    TRISBbits.TRISB7 = 0;   //set RB7 as an output


    OPTION_REGbits.PSA = 0; //Prescaler assigned to Timer 0 (other option is to
                            //the Watchdog timer (WDT))

    OPTION_REGbits.PS = 0b111;  //Set the prescaler to 1:256
    OPTION_REGbits.T0CS = 0;    //Use the instruction clock (Fcy/4) as the timer
                                //clock. Other option is an external oscillator
                                //or clock on the T0CKI pin.

    INTCONbits.T0IF = 0;        //Clear the Timer 0 interrupt flag
    TMR0 = 0;                   //Load a value of 0 into the timer
    INTCONbits.T0IE = 1;        //Enable the Timer 0 interrupt

    INTCONbits.GIE = 1;         //Set the Global Interrupt Enable
    while(1)
    {
    }

    return 0;
}